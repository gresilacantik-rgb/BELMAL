const money=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
let products=JSON.parse(localStorage.getItem('belmal_products')||'null')||[
{id:1,name:'Handbody Pemutih Glow Beauty',price:45000,cat:'Skincare',emoji:'🧴',image:''},
{id:2,name:'Jilbab Instan Bella',price:35000,cat:'Fashion',emoji:'🧕',image:''},
{id:3,name:'Tahu Kan Tenggiri Khas Maluku Utara',price:15000,cat:'Makanan',emoji:'🍢',image:''},
{id:4,name:'Kemeja Pria Casual',price:85000,cat:'Fashion',emoji:'👕',image:''},
{id:5,name:'Smartphone Android',price:1500000,cat:'Elektronik',emoji:'📱',image:''},
{id:6,name:'Peralatan Rumah Tangga',price:65000,cat:'Rumah',emoji:'🏠',image:''}
];
let cart=JSON.parse(localStorage.getItem('belmal_cart')||'[]');
let orders=JSON.parse(localStorage.getItem('belmal_orders')||'[]');
let activeCat='';
function save(){localStorage.setItem('belmal_products',JSON.stringify(products));localStorage.setItem('belmal_cart',JSON.stringify(cart));localStorage.setItem('belmal_orders',JSON.stringify(orders));updateCount()}
function updateCount(){document.getElementById('cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0)}
function showPage(id){
 document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));document.getElementById(id).classList.add('active');
 document.querySelectorAll('.bottom button').forEach(b=>b.classList.toggle('active',b.dataset.page===id));
 if(id==='home')renderProducts();if(id==='cart')renderCart();if(id==='checkout')renderCheckout();if(id==='orders')renderOrders();if(id==='admin')renderAdmin();if(id==='categories')renderCategories();
 scrollTo(0,0);
}
function filterCat(c){activeCat=c;showPage('home');renderProducts()}
function clearFilter(){activeCat='';document.getElementById('searchInput').value='';renderProducts()}
function renderProducts(){
 let q=(document.getElementById('searchInput')?.value||'').toLowerCase();
 let list=products.filter(p=>(!activeCat||p.cat===activeCat)&&(!q||p.name.toLowerCase().includes(q)));
 document.getElementById('productGrid').innerHTML=list.map(card).join('')||'<p>Produk tidak ditemukan.</p>';
}
function card(p){return `<article class="card"><div class="pic">${p.image?`<img src="${p.image}" alt="">`:p.emoji}</div><div class="body"><h3>${p.name}</h3><div class="price">${money(p.price)}</div><div class="muted">${p.cat} • Stok tersedia</div><button class="buy" onclick="openDetail(${p.id})">Lihat Produk</button></div></article>`}
function openDetail(id){let p=products.find(x=>x.id===id);document.getElementById('detailContent').innerHTML=`<div class="detailBox"><div class="detailImg">${p.image?`<img src="${p.image}" alt="">`:p.emoji}</div><h2>${p.name}</h2><div class="price">${money(p.price)}</div><p class="muted">Produk pilihan BELMAL • ${p.cat}</p><p>Belanja mudah melalui BELMAL. Hubungi toko jika membutuhkan informasi lebih lanjut.</p><div class="qty"><button onclick="changeTemp(-1)">−</button><b id="tempQty">1</b><button onclick="changeTemp(1)">+</button></div><button class="primary full" onclick="addCart(${p.id})">🛒 Masukkan Keranjang</button><button class="buy full" onclick="buyNow(${p.id})">Beli Sekarang</button></div>`;window.tempQty=1;showPage('detail')}
function changeTemp(n){window.tempQty=Math.max(1,(window.tempQty||1)+n);document.getElementById('tempQty').textContent=window.tempQty}
function addCart(id,qty=window.tempQty||1){let x=cart.find(i=>i.id===id);if(x)x.qty+=qty;else cart.push({id,qty});save();alert('Produk masuk ke keranjang 🛒');}
function buyNow(id){addCart(id);showPage('cart')}
function renderCart(){
 if(!cart.length){document.getElementById('cartContent').innerHTML='<div class="summary">Keranjang masih kosong. Yuk belanja! 🛍️</div>';return}
 let rows=cart.map(i=>{let p=products.find(x=>x.id===i.id);return `<div class="cartRow"><div class="thumb">${p.image?`<img src="${p.image}">`:p.emoji}</div><div class="grow"><b>${p.name}</b><div class="price">${money(p.price)}</div><div class="qty"><button onclick="cartQty(${p.id},-1)">−</button>${i.qty}<button onclick="cartQty(${p.id},1)">+</button></div></div><button onclick="removeCart(${p.id})">🗑️</button></div>`}).join('');
 let sub=cart.reduce((s,i)=>s+products.find(p=>p.id===i.id).price*i.qty,0);
 document.getElementById('cartContent').innerHTML=`<div class="summary">${rows}<hr><div class="totalLine"><span>Subtotal</span><b>${money(sub)}</b></div><button class="primary full" onclick="showPage('checkout')">Checkout</button></div>`;
}
function cartQty(id,n){let x=cart.find(i=>i.id===id);x.qty+=n;if(x.qty<1)cart=cart.filter(i=>i.id!==id);save();renderCart()}
function removeCart(id){cart=cart.filter(i=>i.id!==id);save();renderCart()}
function renderCheckout(){let sub=cart.reduce((s,i)=>s+products.find(p=>p.id===i.id).price*i.qty,0);document.getElementById('checkoutSummary').innerHTML=`<div class="totalLine"><span>Subtotal</span><b>${money(sub)}</b></div><div class="totalLine"><span>Ongkir</span><b>${money(18000)}</b></div><hr><div class="totalLine"><b>Total</b><b>${money(sub+18000)}</b></div>`}
function placeOrder(e){e.preventDefault();if(!cart.length)return;let sub=cart.reduce((s,i)=>s+products.find(p=>p.id===i.id).price*i.qty,0);orders.unshift({id:'BLM'+Date.now().toString().slice(-7),date:new Date().toLocaleString('id-ID'),name:document.getElementById('custName').value,phone:document.getElementById('custPhone').value,address:document.getElementById('custAddress').value,payment:document.getElementById('payment').value,total:sub+18000,items:cart.map(x=>({...x})) ,status:'Diproses'});document.getElementById('profileName').textContent=document.getElementById('custName').value;document.getElementById('profilePhone').textContent=document.getElementById('custPhone').value;cart=[];save();alert('Pesanan berhasil dibuat! 🎉');showPage('orders')}
function renderOrders(){document.getElementById('ordersContent').innerHTML=orders.length?orders.map(o=>`<div class="order"><div class="orderHead"><b>#${o.id}</b><span class="status">${o.status}</span></div><div class="muted">${o.date}</div><p>Total: <b>${money(o.total)}</b></p><small>Pembayaran: ${o.payment}</small></div>`).join(''):'<div class="summary">Belum ada pesanan.</div>'}
function renderCategories(){let cats=[['🧴','Skincare'],['👕','Fashion'],['🍜','Makanan'],['📱','Elektronik'],['🏠','Rumah']];document.getElementById('categoryList').innerHTML=cats.map(c=>`<button class="categoryItem" onclick="filterCat('${c[1]}')"><span class="emoji">${c[0]}</span><b>${c[1]}</b><span>›</span></button>`).join('')}
function addProduct(e){e.preventDefault();products.unshift({id:Date.now(),name:pName.value,price:Number(pPrice.value),cat:pCat.value,emoji:'🛍️',image:pImage.value});save();e.target.reset();renderAdmin();renderProducts();alert('Produk berhasil ditambahkan')}
function renderAdmin(){statProducts.textContent=products.length;statOrders.textContent=orders.length;statRevenue.textContent=money(orders.reduce((s,o)=>s+o.total,0));adminProducts.innerHTML=products.map(p=>`<div class="adminItem"><span>${p.emoji} <b>${p.name}</b><br><small>${money(p.price)} • ${p.cat}</small></span><button onclick="deleteProduct(${p.id})">🗑️</button></div>`).join('')}
function deleteProduct(id){if(confirm('Hapus produk ini?')){products=products.filter(p=>p.id!==id);cart=cart.filter(i=>i.id!==id);save();renderAdmin();renderProducts()}}
function resetData(){if(confirm('Reset semua data demo?')){localStorage.clear();location.reload()}}
updateCount();renderProducts();renderCategories();
# BELMAL — Belanja Maluku Utara
## Versi aplikasi installable (PWA)

Ini adalah versi pertama BELMAL yang dapat dipasang dari Chrome Android sebagai aplikasi layar penuh.

### Cara mencoba
- Untuk sekadar melihat: buka `index.html`.
- Untuk fitur **Install aplikasi** dan offline cache, file harus dijalankan melalui HTTPS atau localhost. Hosting gratis seperti GitHub Pages/Netlify/Vercel dapat digunakan.

### Cara memasang di Android
Setelah proyek di-host pada HTTPS:
1. Buka alamat BELMAL di Chrome.
2. Pilih menu ⋮.
3. Pilih **Tambahkan ke layar utama / Install app**.
4. BELMAL akan tampil seperti aplikasi di HP.

### Fitur
Beranda, kategori, pencarian, detail produk, keranjang, checkout, pesanan, akun, dan admin demo.

### Belum termasuk
Database online, login, payment gateway, ongkir otomatis, notifikasi push, dan backend keamanan. Fitur-fitur ini diperlukan sebelum dipakai sebagai toko online produksi.
